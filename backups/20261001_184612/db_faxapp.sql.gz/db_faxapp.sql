--
-- PostgreSQL database dump
--

\restrict HTzPxOrgnB9zf9SAQP9A9ecThHW4hRdsAVM6BgVemzvctjmzCxMxTFvV5IRcOQH

-- Dumped from database version 13.23
-- Dumped by pg_dump version 13.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(128) NOT NULL,
    key_prefix character varying(12) NOT NULL,
    created_by integer,
    is_active boolean DEFAULT true NOT NULL,
    last_used_at timestamp with time zone,
    call_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_keys_id_seq OWNER TO postgres;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    user_id integer,
    action character varying(40),
    detail character varying(500),
    ip character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO faxapp;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO faxapp;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: contact_group_members; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.contact_group_members (
    group_id integer NOT NULL,
    contact_id integer NOT NULL
);


ALTER TABLE public.contact_group_members OWNER TO faxapp;

--
-- Name: contact_groups; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.contact_groups (
    id integer NOT NULL,
    owner_id integer,
    name character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.contact_groups OWNER TO faxapp;

--
-- Name: contact_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.contact_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_groups_id_seq OWNER TO faxapp;

--
-- Name: contact_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.contact_groups_id_seq OWNED BY public.contact_groups.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    owner_id integer,
    name character varying(100) NOT NULL,
    fax_number character varying(32) NOT NULL,
    company character varying(120),
    memo character varying(255),
    is_shared boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.contacts OWNER TO faxapp;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO faxapp;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: cover_templates; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.cover_templates (
    id integer NOT NULL,
    owner_id integer,
    name character varying(100) NOT NULL,
    content text,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cover_templates OWNER TO faxapp;

--
-- Name: cover_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.cover_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cover_templates_id_seq OWNER TO faxapp;

--
-- Name: cover_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.cover_templates_id_seq OWNED BY public.cover_templates.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    parent_id integer,
    fax_number character varying(32),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.departments OWNER TO faxapp;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO faxapp;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: error_log; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.error_log (
    id integer NOT NULL,
    code character varying(40) NOT NULL,
    category character varying(20) NOT NULL,
    detail text,
    context jsonb,
    path character varying(200),
    user_id integer,
    job_id integer,
    resolved boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.error_log OWNER TO faxapp;

--
-- Name: error_log_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.error_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.error_log_id_seq OWNER TO faxapp;

--
-- Name: error_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.error_log_id_seq OWNED BY public.error_log.id;


--
-- Name: fax_jobs; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.fax_jobs (
    id integer NOT NULL,
    user_id integer,
    dept_id integer,
    to_number character varying(32) NOT NULL,
    to_name character varying(100),
    file_name character varying(255),
    file_path character varying(500),
    pages integer DEFAULT 0,
    cover_used boolean DEFAULT false,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    server_job_id character varying(64),
    retry_count integer DEFAULT 0,
    result_text character varying(255),
    batch_id character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    max_retries integer DEFAULT 3,
    next_retry_at timestamp with time zone,
    last_error_code character varying(40),
    scheduled_at timestamp with time zone,
    pages_sent integer,
    diag_category character varying(40),
    t38_used boolean,
    transfer_rate character varying(20),
    hangup_cause character varying(60),
    api_key_id integer,
    ecm_used boolean,
    bad_rows integer
);


ALTER TABLE public.fax_jobs OWNER TO faxapp;

--
-- Name: COLUMN fax_jobs.status; Type: COMMENT; Schema: public; Owner: faxapp
--

COMMENT ON COLUMN public.fax_jobs.status IS 'pending/scheduled/queued/sending/sent/failed/cancelled/retry_wait';


--
-- Name: fax_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.fax_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fax_jobs_id_seq OWNER TO faxapp;

--
-- Name: fax_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.fax_jobs_id_seq OWNED BY public.fax_jobs.id;


--
-- Name: fax_received; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.fax_received (
    id integer NOT NULL,
    from_number character varying(32),
    to_number character varying(32),
    dept_id integer,
    user_id integer,
    file_path character varying(500),
    pages integer DEFAULT 0,
    rate character varying(16),
    is_read boolean DEFAULT false NOT NULL,
    memo character varying(500),
    received_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fax_received OWNER TO faxapp;

--
-- Name: fax_received_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.fax_received_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fax_received_id_seq OWNER TO faxapp;

--
-- Name: fax_received_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.fax_received_id_seq OWNED BY public.fax_received.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    level character varying(10) DEFAULT 'info'::character varying NOT NULL,
    title character varying(120) NOT NULL,
    body text,
    category character varying(30),
    ref_type character varying(20),
    ref_id integer,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: notify_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notify_config (
    id integer DEFAULT 1 NOT NULL,
    webhook_url text,
    notify_on_fail boolean DEFAULT true NOT NULL,
    notify_on_recv boolean DEFAULT false NOT NULL,
    fault_filter character varying(20) DEFAULT 'local'::character varying,
    CONSTRAINT single_row CHECK ((id = 1))
);


ALTER TABLE public.notify_config OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: faxapp
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    email character varying(160),
    dept_id integer,
    fax_number character varying(32),
    role character varying(20) DEFAULT 'user'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login timestamp with time zone
);


ALTER TABLE public.users OWNER TO faxapp;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: faxapp
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO faxapp;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: faxapp
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: contact_groups id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contact_groups ALTER COLUMN id SET DEFAULT nextval('public.contact_groups_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: cover_templates id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.cover_templates ALTER COLUMN id SET DEFAULT nextval('public.cover_templates_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: error_log id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.error_log ALTER COLUMN id SET DEFAULT nextval('public.error_log_id_seq'::regclass);


--
-- Name: fax_jobs id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_jobs ALTER COLUMN id SET DEFAULT nextval('public.fax_jobs_id_seq'::regclass);


--
-- Name: fax_received id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_received ALTER COLUMN id SET DEFAULT nextval('public.fax_received_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, name, key_hash, key_prefix, created_by, is_active, last_used_at, call_count, created_at) FROM stdin;
1	ERP	f1828610ebd34c144ef3b586432750c8e384f4c7ebb3394fefc70d5b6aaf5bb5	fx_ZxnyY17	2	f	\N	0	2026-08-17 09:04:22.334839+09
2	ERP	d97b5af5249e1539d68b343f2c666443eb946be8db1fff7b30420a92e4021f96	fx_x1cznY7	2	f	\N	0	2026-08-18 13:40:00.719036+09
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.audit_log (id, user_id, action, detail, ip, created_at) FROM stdin;
1	2	login	success	192.168.219.141	2026-08-08 19:54:58.427001+09
2	2	login	success	192.168.219.141	2026-08-08 20:07:16.966689+09
3	2	login	success	192.168.219.141	2026-08-08 20:07:31.131037+09
35	2	login	success	192.168.219.141	2026-08-09 05:10:50.693336+09
36	2	send	to=1002 job=1	\N	2026-08-09 05:22:47.475468+09
37	2	login_fail	bad password	127.0.0.1	2026-08-09 05:25:51.238278+09
38	2	login_fail	bad password	127.0.0.1	2026-08-09 05:26:25.634357+09
39	2	login_fail	bad password	127.0.0.1	2026-08-09 05:26:37.627029+09
40	2	login_fail	bad password	127.0.0.1	2026-08-09 05:27:05.245466+09
41	2	login_fail	bad password	127.0.0.1	2026-08-09 05:27:05.451464+09
42	2	login	success	127.0.0.1	2026-08-09 05:28:51.611206+09
43	2	send	to=1002 job=2	\N	2026-08-09 05:28:52.936862+09
44	2	send	to=1002 job=3	\N	2026-08-09 05:28:53.71929+09
45	2	send	to=1002 job=4	\N	2026-08-09 05:28:54.455748+09
46	2	send	to=1002 job=5	\N	2026-08-09 05:28:55.164477+09
47	2	send	to=1002 job=6	\N	2026-08-09 05:28:55.952163+09
48	2	send	to=1002 job=7	\N	2026-08-09 05:28:56.683278+09
49	2	send	to=1002 job=8	\N	2026-08-09 05:28:57.421753+09
50	2	send	to=1002 job=9	\N	2026-08-09 05:28:58.108907+09
51	2	send	to=1002 job=10	\N	2026-08-09 05:28:58.843542+09
52	2	send	to=1002 job=11	\N	2026-08-09 05:28:59.554583+09
53	2	login	success	127.0.0.1	2026-08-09 05:29:34.410922+09
54	2	send	to=1002 job=12	\N	2026-08-09 05:29:34.797929+09
55	2	send	to=1002 job=13	\N	2026-08-09 05:29:35.487403+09
56	2	send	to=1002 job=14	\N	2026-08-09 05:29:36.173307+09
57	2	send	to=1002 job=15	\N	2026-08-09 05:29:36.86275+09
58	2	send	to=1002 job=16	\N	2026-08-09 05:29:37.575029+09
59	2	send	to=1002 job=17	\N	2026-08-09 05:29:38.27515+09
60	2	send	to=1002 job=18	\N	2026-08-09 05:29:39.030888+09
61	2	send	to=1002 job=19	\N	2026-08-09 05:29:39.736741+09
62	2	send	to=1002 job=20	\N	2026-08-09 05:29:40.433368+09
63	2	send	to=1002 job=21	\N	2026-08-09 05:29:41.127864+09
64	2	send	to=1002 job=22	\N	2026-08-09 05:29:41.818665+09
65	2	send	to=1002 job=23	\N	2026-08-09 05:29:42.513547+09
66	2	send	to=1002 job=24	\N	2026-08-09 05:29:43.210984+09
67	2	send	to=1002 job=25	\N	2026-08-09 05:29:43.908269+09
68	2	send	to=1002 job=26	\N	2026-08-09 05:29:44.613696+09
69	2	send	to=1002 job=27	\N	2026-08-09 05:29:45.441359+09
70	2	send	to=1002 job=28	\N	2026-08-09 05:29:46.195823+09
71	2	send	to=1002 job=29	\N	2026-08-09 05:29:46.903476+09
72	2	send	to=1002 job=30	\N	2026-08-09 05:29:47.623609+09
73	2	send	to=1002 job=31	\N	2026-08-09 05:29:48.338849+09
74	2	send	to=1002 job=32	\N	2026-08-09 05:29:49.056228+09
75	2	send	to=1002 job=33	\N	2026-08-09 05:29:49.771345+09
76	2	send	to=1002 job=34	\N	2026-08-09 05:29:50.525974+09
77	2	send	to=1002 job=35	\N	2026-08-09 05:29:51.235164+09
78	2	send	to=1002 job=36	\N	2026-08-09 05:29:51.938098+09
79	2	send	to=1002 job=37	\N	2026-08-09 05:29:52.662197+09
80	2	send	to=1002 job=38	\N	2026-08-09 05:29:53.401225+09
81	2	send	to=1002 job=39	\N	2026-08-09 05:29:54.105401+09
82	2	send	to=1002 job=40	\N	2026-08-09 05:29:54.803537+09
83	2	send	to=1002 job=41	\N	2026-08-09 05:29:55.510012+09
84	2	send	to=1002 job=42	\N	2026-08-09 05:29:56.209192+09
85	2	send	to=1002 job=43	\N	2026-08-09 05:29:56.928784+09
86	2	send	to=1002 job=44	\N	2026-08-09 05:29:57.661531+09
87	2	send	to=1002 job=45	\N	2026-08-09 05:29:58.396988+09
88	2	send	to=1002 job=46	\N	2026-08-09 05:29:59.126126+09
89	2	send	to=1002 job=47	\N	2026-08-09 05:29:59.847882+09
90	2	send	to=1002 job=48	\N	2026-08-09 05:30:00.570135+09
91	2	send	to=1002 job=49	\N	2026-08-09 05:30:01.28305+09
92	2	send	to=1002 job=50	\N	2026-08-09 05:30:01.989923+09
93	2	send	to=1002 job=51	\N	2026-08-09 05:30:02.700279+09
94	2	send	to=1002 job=52	\N	2026-08-09 05:30:03.444375+09
95	2	send	to=1002 job=53	\N	2026-08-09 05:30:04.167446+09
96	2	send	to=1002 job=54	\N	2026-08-09 05:30:04.88048+09
97	2	send	to=1002 job=55	\N	2026-08-09 05:30:05.584934+09
98	2	send	to=1002 job=56	\N	2026-08-09 05:30:06.291607+09
99	2	send	to=1002 job=57	\N	2026-08-09 05:30:07.006867+09
100	2	send	to=1002 job=58	\N	2026-08-09 05:30:07.713115+09
101	2	send	to=1002 job=59	\N	2026-08-09 05:30:08.422485+09
102	2	send	to=1002 job=60	\N	2026-08-09 05:30:09.130889+09
103	2	send	to=1002 job=61	\N	2026-08-09 05:30:09.855626+09
104	2	send	to=1002 job=62	\N	2026-08-09 05:30:10.579611+09
105	2	send	to=1002 job=63	\N	2026-08-09 05:30:11.300944+09
106	2	send	to=1002 job=64	\N	2026-08-09 05:30:12.014607+09
107	2	send	to=1002 job=65	\N	2026-08-09 05:30:12.735422+09
108	2	send	to=1002 job=66	\N	2026-08-09 05:30:13.454717+09
109	2	send	to=1002 job=67	\N	2026-08-09 05:30:14.181554+09
110	2	send	to=1002 job=68	\N	2026-08-09 05:30:14.923934+09
111	2	send	to=1002 job=69	\N	2026-08-09 05:30:15.676817+09
112	2	send	to=1002 job=70	\N	2026-08-09 05:30:16.380557+09
113	2	send	to=1002 job=71	\N	2026-08-09 05:30:17.095104+09
114	2	send	to=1002 job=72	\N	2026-08-09 05:30:17.814789+09
115	2	send	to=1002 job=73	\N	2026-08-09 05:30:18.529285+09
116	2	send	to=1002 job=74	\N	2026-08-09 05:30:19.24432+09
117	2	send	to=1002 job=75	\N	2026-08-09 05:30:19.95674+09
118	2	send	to=1002 job=76	\N	2026-08-09 05:30:20.709923+09
119	2	send	to=1002 job=77	\N	2026-08-09 05:30:21.43424+09
120	2	send	to=1002 job=78	\N	2026-08-09 05:30:22.14576+09
121	2	send	to=1002 job=79	\N	2026-08-09 05:30:22.88239+09
122	2	send	to=1002 job=80	\N	2026-08-09 05:30:23.598322+09
123	2	send	to=1002 job=81	\N	2026-08-09 05:30:24.321315+09
124	2	send	to=1002 job=82	\N	2026-08-09 05:30:25.058959+09
125	2	send	to=1002 job=83	\N	2026-08-09 05:30:25.769194+09
126	2	send	to=1002 job=84	\N	2026-08-09 05:30:26.500222+09
127	2	send	to=1002 job=85	\N	2026-08-09 05:30:27.239617+09
128	2	send	to=1002 job=86	\N	2026-08-09 05:30:27.950117+09
129	2	send	to=1002 job=87	\N	2026-08-09 05:30:28.697039+09
130	2	send	to=1002 job=88	\N	2026-08-09 05:30:29.413071+09
131	2	send	to=1002 job=89	\N	2026-08-09 05:30:30.126742+09
132	2	send	to=1002 job=90	\N	2026-08-09 05:30:30.842549+09
133	2	send	to=1002 job=91	\N	2026-08-09 05:30:31.584768+09
134	2	send	to=1002 job=92	\N	2026-08-09 05:30:32.311861+09
135	2	send	to=1002 job=93	\N	2026-08-09 05:30:33.030174+09
136	2	send	to=1002 job=94	\N	2026-08-09 05:30:33.763412+09
137	2	send	to=1002 job=95	\N	2026-08-09 05:30:34.48457+09
138	2	send	to=1002 job=96	\N	2026-08-09 05:30:35.190461+09
139	2	send	to=1002 job=97	\N	2026-08-09 05:30:35.912458+09
140	2	send	to=1002 job=98	\N	2026-08-09 05:30:36.62615+09
141	2	send	to=1002 job=99	\N	2026-08-09 05:30:37.331213+09
142	2	send	to=1002 job=100	\N	2026-08-09 05:30:38.049997+09
143	2	send	to=1002 job=101	\N	2026-08-09 05:30:38.754716+09
144	2	send	to=1002 job=102	\N	2026-08-09 05:30:39.46032+09
145	2	send	to=1002 job=103	\N	2026-08-09 05:30:40.170542+09
146	2	send	to=1002 job=104	\N	2026-08-09 05:30:40.88293+09
147	2	send	to=1002 job=105	\N	2026-08-09 05:30:41.603323+09
148	2	send	to=1002 job=106	\N	2026-08-09 05:30:42.312198+09
149	2	send	to=1002 job=107	\N	2026-08-09 05:30:43.028503+09
150	2	send	to=1002 job=108	\N	2026-08-09 05:30:43.737913+09
151	2	send	to=1002 job=109	\N	2026-08-09 05:30:44.45882+09
152	2	send	to=1002 job=110	\N	2026-08-09 05:30:45.183719+09
153	2	send	to=1002 job=111	\N	2026-08-09 05:30:45.893115+09
154	2	send	to=1002 job=112	\N	2026-08-09 05:30:46.616039+09
155	2	send	to=1002 job=113	\N	2026-08-09 05:30:47.329229+09
156	2	send	to=1002 job=114	\N	2026-08-09 05:30:48.050445+09
157	2	send	to=1002 job=115	\N	2026-08-09 05:30:48.765862+09
158	2	send	to=1002 job=116	\N	2026-08-09 05:30:49.47572+09
159	2	send	to=1002 job=117	\N	2026-08-09 05:30:50.180399+09
160	2	send	to=1002 job=118	\N	2026-08-09 05:30:50.890619+09
161	2	send	to=1002 job=119	\N	2026-08-09 05:30:51.597188+09
162	2	send	to=1002 job=120	\N	2026-08-09 05:30:52.304327+09
163	2	send	to=1002 job=121	\N	2026-08-09 05:30:53.120515+09
164	2	send	to=1002 job=122	\N	2026-08-09 05:30:53.831708+09
165	2	send	to=1002 job=123	\N	2026-08-09 05:30:54.557703+09
166	2	send	to=1002 job=124	\N	2026-08-09 05:30:55.282511+09
167	2	send	to=1002 job=125	\N	2026-08-09 05:30:55.98742+09
168	2	send	to=1002 job=126	\N	2026-08-09 05:30:56.693361+09
169	2	send	to=1002 job=127	\N	2026-08-09 05:30:57.414304+09
170	2	send	to=1002 job=128	\N	2026-08-09 05:30:58.146137+09
171	2	send	to=1002 job=129	\N	2026-08-09 05:30:58.85599+09
172	2	send	to=1002 job=130	\N	2026-08-09 05:30:59.565697+09
173	2	send	to=1002 job=131	\N	2026-08-09 05:31:00.280473+09
174	2	send	to=1002 job=132	\N	2026-08-09 05:31:01.002567+09
175	2	send	to=1002 job=133	\N	2026-08-09 05:31:01.721879+09
176	2	send	to=1002 job=134	\N	2026-08-09 05:31:02.425271+09
177	2	send	to=1002 job=135	\N	2026-08-09 05:31:03.139313+09
178	2	send	to=1002 job=136	\N	2026-08-09 05:31:03.843126+09
179	2	send	to=1002 job=137	\N	2026-08-09 05:31:04.560025+09
180	2	send	to=1002 job=138	\N	2026-08-09 05:31:05.285026+09
181	2	send	to=1002 job=139	\N	2026-08-09 05:31:06.008468+09
182	2	send	to=1002 job=140	\N	2026-08-09 05:31:06.714942+09
183	2	login	success	192.168.219.141	2026-08-09 05:34:37.577076+09
184	2	login	success	192.168.219.141	2026-08-09 05:41:55.75155+09
185	2	cancel	job=140	\N	2026-08-09 05:42:18.090044+09
186	2	cancel	job=139	\N	2026-08-09 05:42:19.033597+09
187	2	cancel	job=138	\N	2026-08-09 05:42:19.551494+09
188	2	cancel	job=137	\N	2026-08-09 05:42:20.419611+09
189	2	cancel	job=136	\N	2026-08-09 05:42:20.772921+09
190	2	login	success	192.168.219.141	2026-08-09 05:49:37.973045+09
191	2	login	success	192.168.219.141	2026-08-13 02:17:01.118858+09
192	2	login	success	192.168.219.141	2026-08-13 08:06:27.030894+09
193	2	login	success	192.168.219.141	2026-08-13 09:00:02.732672+09
194	2	login	success	192.168.219.141	2026-08-13 09:12:06.944873+09
195	2	login	success	192.168.219.141	2026-08-13 09:17:33.508628+09
196	2	login	success	192.168.219.141	2026-08-13 09:21:49.402756+09
197	2	login	success	192.168.219.141	2026-08-13 18:38:40.530477+09
198	2	login	success	192.168.219.141	2026-08-13 18:53:57.256753+09
199	2	login	success	192.168.219.141	2026-08-13 18:59:56.227327+09
200	2	login	success	192.168.219.141	2026-08-13 19:05:43.464173+09
201	2	login	success	192.168.219.141	2026-08-14 03:44:34.399067+09
202	2	cancel	job=140	\N	2026-08-14 03:45:14.019221+09
203	2	cancel	job=139	\N	2026-08-14 03:45:14.754407+09
204	2	cancel	job=138	\N	2026-08-14 03:45:15.194498+09
205	2	cancel	job=137	\N	2026-08-14 03:45:15.771125+09
206	2	login	success	192.168.219.141	2026-08-14 04:30:55.538735+09
207	2	send	to=1002 job=141	\N	2026-08-14 04:30:59.311072+09
208	2	send	to=1002 job=142	\N	2026-08-14 04:31:08.234182+09
209	2	send	to=1002 job=143	\N	2026-08-14 04:31:08.294494+09
210	2	send	to=1002 job=144	\N	2026-08-14 04:31:08.353307+09
211	2	send	to=1002 job=145	\N	2026-08-14 04:31:08.409299+09
212	2	send	to=1002 job=146	\N	2026-08-14 04:31:08.469384+09
213	2	login	success	192.168.219.141	2026-08-14 04:40:02.210683+09
214	2	send	to=1002 job=147	\N	2026-08-14 04:40:08.328233+09
215	2	send	to=1002 job=148	\N	2026-08-14 04:40:11.935655+09
216	2	send	to=1002 job=149	\N	2026-08-14 04:40:11.996845+09
217	2	send	to=1002 job=150	\N	2026-08-14 04:40:12.056161+09
218	2	send	to=1002 job=151	\N	2026-08-14 04:40:12.116989+09
219	2	send	to=1002 job=152	\N	2026-08-14 04:40:12.178888+09
220	2	send	to=1002 job=153	\N	2026-08-14 04:40:12.631775+09
221	2	send	to=1002 job=154	\N	2026-08-14 04:40:12.693124+09
222	2	send	to=1002 job=155	\N	2026-08-14 04:40:12.753316+09
223	2	send	to=1002 job=156	\N	2026-08-14 04:40:12.822429+09
224	2	send	to=1002 job=157	\N	2026-08-14 04:40:12.889759+09
246	2	login	success	192.168.0.13	2026-08-14 13:27:07.720208+09
247	2	send	to=1002 job=180	\N	2026-08-14 13:27:56.354833+09
248	2	cancel	job=180	\N	2026-08-14 13:28:27.356746+09
249	2	login	success	192.168.0.13	2026-08-14 14:28:44.835982+09
250	2	send	to=1002 job=181	\N	2026-08-14 14:28:47.716076+09
251	2	cancel	job=181	\N	2026-08-14 14:29:04.063467+09
252	2	login	success	192.168.0.13	2026-08-14 14:56:16.161758+09
253	2	login	success	192.168.219.141	2026-08-16 03:37:33.057785+09
254	2	login	success	192.168.219.141	2026-08-16 04:39:21.882325+09
255	2	login	success	192.168.219.141	2026-08-16 10:16:40.721593+09
256	2	login	success	192.168.219.141	2026-08-16 20:22:54.284533+09
257	2	login	success	192.168.219.141	2026-08-16 21:14:19.587221+09
258	2	login	success	192.168.219.141	2026-08-16 21:42:44.263575+09
291	2	login	success	192.168.219.141	2026-08-17 02:13:25.87501+09
292	2	login	success	192.168.219.141	2026-08-17 02:32:47.953731+09
293	2	login	success	192.168.219.141	2026-08-17 02:52:11.953231+09
294	2	login	success	192.168.219.141	2026-08-17 08:54:43.61567+09
295	2	login	success	192.168.219.141	2026-08-17 09:04:06.198239+09
296	2	login	success	192.168.219.141	2026-08-17 09:16:29.177506+09
297	2	login	success	192.168.219.141	2026-08-18 13:38:45.304778+09
330	2	login	success	192.168.219.141	2026-08-18 17:17:23.299279+09
331	2	login	success	192.168.219.141	2026-08-18 18:08:07.44744+09
332	2	login	success	127.0.0.1	2026-08-18 18:49:43.574483+09
333	2	send	to=01012345678 job=182	\N	2026-08-18 18:49:43.782347+09
334	2	send	to=01012345678 job=183	\N	2026-08-18 18:49:43.907269+09
335	2	send	to=01012345678 job=184	\N	2026-08-18 18:49:44.007908+09
336	2	send	to=01012345678 job=185	\N	2026-08-18 18:49:44.104085+09
337	2	send	to=01012345678 job=186	\N	2026-08-18 18:49:44.203266+09
338	2	send	to=01012345678 job=187	\N	2026-08-18 18:49:44.295406+09
339	2	send	to=01012345678 job=188	\N	2026-08-18 18:49:44.386914+09
340	2	send	to=01012345678 job=189	\N	2026-08-18 18:49:44.48085+09
341	2	send	to=01012345678 job=190	\N	2026-08-18 18:49:44.570961+09
342	2	send	to=01012345678 job=191	\N	2026-08-18 18:49:44.664999+09
343	2	send	to=01012345678 job=192	\N	2026-08-18 18:49:44.757446+09
344	2	send	to=01012345678 job=193	\N	2026-08-18 18:49:44.851942+09
345	2	send	to=01012345678 job=194	\N	2026-08-18 18:49:44.942918+09
346	2	send	to=01012345678 job=195	\N	2026-08-18 18:49:45.035674+09
347	2	send	to=01012345678 job=196	\N	2026-08-18 18:49:45.125496+09
348	2	send	to=01012345678 job=197	\N	2026-08-18 18:49:45.220982+09
349	2	send	to=01012345678 job=198	\N	2026-08-18 18:49:45.315614+09
350	2	send	to=01012345678 job=199	\N	2026-08-18 18:49:45.407456+09
355	2	send	to=01012345678 job=204	\N	2026-08-18 18:49:45.872959+09
360	2	send	to=01012345678 job=209	\N	2026-08-18 18:49:46.351147+09
365	2	send	to=01012345678 job=213	\N	2026-08-18 18:54:59.409225+09
370	2	send	to=01012345678 job=218	\N	2026-08-18 18:54:59.888298+09
375	2	send	to=01012345678 job=223	\N	2026-08-18 18:55:00.366708+09
380	2	send	to=01012345678 job=228	\N	2026-08-18 18:55:00.837839+09
385	2	send	to=01012345678 job=233	\N	2026-08-18 18:55:01.312698+09
390	2	send	to=01012345678 job=238	\N	2026-08-18 18:55:01.795784+09
351	2	send	to=01012345678 job=200	\N	2026-08-18 18:49:45.499513+09
356	2	send	to=01012345678 job=205	\N	2026-08-18 18:49:45.968464+09
361	2	send	to=01012345678 job=210	\N	2026-08-18 18:49:46.447999+09
367	2	send	to=01012345678 job=215	\N	2026-08-18 18:54:59.605168+09
372	2	send	to=01012345678 job=220	\N	2026-08-18 18:55:00.080396+09
377	2	send	to=01012345678 job=225	\N	2026-08-18 18:55:00.55449+09
382	2	send	to=01012345678 job=230	\N	2026-08-18 18:55:01.030023+09
387	2	send	to=01012345678 job=235	\N	2026-08-18 18:55:01.506427+09
392	2	send	to=01012345678 job=240	\N	2026-08-18 18:55:01.988671+09
352	2	send	to=01012345678 job=201	\N	2026-08-18 18:49:45.590917+09
357	2	send	to=01012345678 job=206	\N	2026-08-18 18:49:46.063423+09
362	2	send	to=01012345678 job=211	\N	2026-08-18 18:49:46.546706+09
364	2	send	to=01012345678 job=212	\N	2026-08-18 18:54:59.288673+09
369	2	send	to=01012345678 job=217	\N	2026-08-18 18:54:59.79521+09
374	2	send	to=01012345678 job=222	\N	2026-08-18 18:55:00.268506+09
379	2	send	to=01012345678 job=227	\N	2026-08-18 18:55:00.744757+09
384	2	send	to=01012345678 job=232	\N	2026-08-18 18:55:01.214247+09
389	2	send	to=01012345678 job=237	\N	2026-08-18 18:55:01.697947+09
353	2	send	to=01012345678 job=202	\N	2026-08-18 18:49:45.683993+09
358	2	send	to=01012345678 job=207	\N	2026-08-18 18:49:46.160115+09
366	2	send	to=01012345678 job=214	\N	2026-08-18 18:54:59.50667+09
371	2	send	to=01012345678 job=219	\N	2026-08-18 18:54:59.985555+09
376	2	send	to=01012345678 job=224	\N	2026-08-18 18:55:00.461954+09
381	2	send	to=01012345678 job=229	\N	2026-08-18 18:55:00.932091+09
386	2	send	to=01012345678 job=234	\N	2026-08-18 18:55:01.408296+09
391	2	send	to=01012345678 job=239	\N	2026-08-18 18:55:01.890236+09
354	2	send	to=01012345678 job=203	\N	2026-08-18 18:49:45.776298+09
359	2	send	to=01012345678 job=208	\N	2026-08-18 18:49:46.257949+09
363	2	login	success	127.0.0.1	2026-08-18 18:54:59.160936+09
368	2	send	to=01012345678 job=216	\N	2026-08-18 18:54:59.70258+09
373	2	send	to=01012345678 job=221	\N	2026-08-18 18:55:00.174814+09
378	2	send	to=01012345678 job=226	\N	2026-08-18 18:55:00.646722+09
383	2	send	to=01012345678 job=231	\N	2026-08-18 18:55:01.121429+09
388	2	send	to=01012345678 job=236	\N	2026-08-18 18:55:01.600829+09
393	2	send	to=01012345678 job=241	\N	2026-08-18 18:55:02.085495+09
394	2	login	success	127.0.0.1	2026-08-18 19:12:19.121338+09
395	2	send	to=01012345678 job=242	\N	2026-08-18 19:12:19.246335+09
396	2	send	to=01012345678 job=243	\N	2026-08-18 19:12:19.365229+09
397	2	send	to=01012345678 job=244	\N	2026-08-18 19:12:19.461824+09
398	2	send	to=01012345678 job=245	\N	2026-08-18 19:12:19.5581+09
399	2	send	to=01012345678 job=246	\N	2026-08-18 19:12:19.659714+09
400	2	send	to=01012345678 job=247	\N	2026-08-18 19:12:19.75723+09
401	2	send	to=01012345678 job=248	\N	2026-08-18 19:12:19.851865+09
402	2	send	to=01012345678 job=249	\N	2026-08-18 19:12:19.943861+09
403	2	send	to=01012345678 job=250	\N	2026-08-18 19:12:20.03844+09
404	2	send	to=01012345678 job=251	\N	2026-08-18 19:12:20.13253+09
405	2	send	to=01012345678 job=252	\N	2026-08-18 19:12:20.225226+09
406	2	send	to=01012345678 job=253	\N	2026-08-18 19:12:20.318431+09
407	2	send	to=01012345678 job=254	\N	2026-08-18 19:12:20.410954+09
408	2	send	to=01012345678 job=255	\N	2026-08-18 19:12:20.50598+09
409	2	send	to=01012345678 job=256	\N	2026-08-18 19:12:20.598614+09
410	2	send	to=01012345678 job=257	\N	2026-08-18 19:12:20.692916+09
411	2	send	to=01012345678 job=258	\N	2026-08-18 19:12:20.792036+09
412	2	send	to=01012345678 job=259	\N	2026-08-18 19:12:20.888025+09
413	2	send	to=01012345678 job=260	\N	2026-08-18 19:12:20.985674+09
414	2	send	to=01012345678 job=261	\N	2026-08-18 19:12:21.07803+09
415	2	send	to=01012345678 job=262	\N	2026-08-18 19:12:21.172825+09
416	2	send	to=01012345678 job=263	\N	2026-08-18 19:12:21.272484+09
417	2	send	to=01012345678 job=264	\N	2026-08-18 19:12:21.369269+09
418	2	send	to=01012345678 job=265	\N	2026-08-18 19:12:21.469124+09
419	2	send	to=01012345678 job=266	\N	2026-08-18 19:12:21.564928+09
420	2	send	to=01012345678 job=267	\N	2026-08-18 19:12:21.664925+09
421	2	send	to=01012345678 job=268	\N	2026-08-18 19:12:21.766958+09
422	2	send	to=01012345678 job=269	\N	2026-08-18 19:12:21.864528+09
423	2	send	to=01012345678 job=270	\N	2026-08-18 19:12:21.963166+09
424	2	send	to=01012345678 job=271	\N	2026-08-18 19:12:22.063088+09
425	2	login	success	127.0.0.1	2026-08-18 19:17:05.983709+09
426	2	send	to=01012345678 job=272	\N	2026-08-18 19:17:06.110034+09
427	2	send	to=01012345678 job=273	\N	2026-08-18 19:17:06.232315+09
428	2	send	to=01012345678 job=274	\N	2026-08-18 19:17:06.33213+09
429	2	send	to=01012345678 job=275	\N	2026-08-18 19:17:06.432736+09
430	2	send	to=01012345678 job=276	\N	2026-08-18 19:17:06.529503+09
431	2	send	to=01012345678 job=277	\N	2026-08-18 19:17:06.631296+09
432	2	send	to=01012345678 job=278	\N	2026-08-18 19:17:06.730121+09
433	2	send	to=01012345678 job=279	\N	2026-08-18 19:17:06.826517+09
434	2	send	to=01012345678 job=280	\N	2026-08-18 19:17:06.92527+09
435	2	send	to=01012345678 job=281	\N	2026-08-18 19:17:07.026046+09
436	2	send	to=01012345678 job=282	\N	2026-08-18 19:17:07.126505+09
437	2	send	to=01012345678 job=283	\N	2026-08-18 19:17:07.22446+09
438	2	send	to=01012345678 job=284	\N	2026-08-18 19:17:07.321418+09
439	2	send	to=01012345678 job=285	\N	2026-08-18 19:17:07.416568+09
440	2	send	to=01012345678 job=286	\N	2026-08-18 19:17:07.511969+09
441	2	send	to=01012345678 job=287	\N	2026-08-18 19:17:07.606291+09
442	2	send	to=01012345678 job=288	\N	2026-08-18 19:17:07.703352+09
443	2	send	to=01012345678 job=289	\N	2026-08-18 19:17:07.79661+09
444	2	send	to=01012345678 job=290	\N	2026-08-18 19:17:07.89012+09
445	2	send	to=01012345678 job=291	\N	2026-08-18 19:17:07.98636+09
446	2	send	to=01012345678 job=292	\N	2026-08-18 19:17:08.088523+09
447	2	send	to=01012345678 job=293	\N	2026-08-18 19:17:08.189873+09
448	2	send	to=01012345678 job=294	\N	2026-08-18 19:17:08.286552+09
449	2	send	to=01012345678 job=295	\N	2026-08-18 19:17:08.387248+09
450	2	send	to=01012345678 job=296	\N	2026-08-18 19:17:08.490367+09
451	2	send	to=01012345678 job=297	\N	2026-08-18 19:17:08.588958+09
452	2	send	to=01012345678 job=298	\N	2026-08-18 19:17:08.686535+09
453	2	send	to=01012345678 job=299	\N	2026-08-18 19:17:08.784964+09
454	2	send	to=01012345678 job=300	\N	2026-08-18 19:17:08.880567+09
455	2	send	to=01012345678 job=301	\N	2026-08-18 19:17:08.975288+09
456	2	login	success	127.0.0.1	2026-08-18 19:24:29.34757+09
457	2	login	success	192.168.219.141	2026-08-18 19:24:51.366745+09
458	2	login	success	127.0.0.1	2026-08-18 19:25:59.132627+09
459	2	login	success	127.0.0.1	2026-08-18 19:30:57.267002+09
460	2	login	success	192.168.219.141	2026-08-18 23:34:07.63326+09
461	2	login	success	127.0.0.1	2026-08-18 23:43:39.318114+09
462	2	send	to=01012345678 job=392	\N	2026-08-18 23:43:39.526069+09
463	2	send	to=01012345678 job=393	\N	2026-08-18 23:43:39.651199+09
464	2	send	to=01012345678 job=394	\N	2026-08-18 23:43:39.749502+09
465	2	send	to=01012345678 job=395	\N	2026-08-18 23:43:39.846079+09
466	2	send	to=01012345678 job=396	\N	2026-08-18 23:43:39.941238+09
467	2	send	to=01012345678 job=397	\N	2026-08-18 23:43:40.035745+09
468	2	send	to=01012345678 job=398	\N	2026-08-18 23:43:40.129508+09
469	2	send	to=01012345678 job=399	\N	2026-08-18 23:43:40.229094+09
470	2	send	to=01012345678 job=400	\N	2026-08-18 23:43:40.324795+09
471	2	send	to=01012345678 job=401	\N	2026-08-18 23:43:40.418717+09
472	2	send	to=01012345678 job=402	\N	2026-08-18 23:43:40.515114+09
473	2	send	to=01012345678 job=403	\N	2026-08-18 23:43:40.608719+09
474	2	send	to=01012345678 job=404	\N	2026-08-18 23:43:40.703901+09
475	2	send	to=01012345678 job=405	\N	2026-08-18 23:43:40.797727+09
476	2	send	to=01012345678 job=406	\N	2026-08-18 23:43:40.894984+09
477	2	send	to=01012345678 job=407	\N	2026-08-18 23:43:40.990348+09
478	2	send	to=01012345678 job=408	\N	2026-08-18 23:43:41.085251+09
479	2	send	to=01012345678 job=409	\N	2026-08-18 23:43:41.181838+09
480	2	send	to=01012345678 job=410	\N	2026-08-18 23:43:41.277293+09
481	2	send	to=01012345678 job=411	\N	2026-08-18 23:43:41.374043+09
482	2	send	to=01012345678 job=412	\N	2026-08-18 23:43:41.469015+09
483	2	send	to=01012345678 job=413	\N	2026-08-18 23:43:41.563945+09
484	2	send	to=01012345678 job=414	\N	2026-08-18 23:43:41.661542+09
485	2	send	to=01012345678 job=415	\N	2026-08-18 23:43:41.761175+09
486	2	send	to=01012345678 job=416	\N	2026-08-18 23:43:41.856899+09
487	2	send	to=01012345678 job=417	\N	2026-08-18 23:43:41.955116+09
488	2	send	to=01012345678 job=418	\N	2026-08-18 23:43:42.055518+09
489	2	send	to=01012345678 job=419	\N	2026-08-18 23:43:42.154727+09
490	2	send	to=01012345678 job=420	\N	2026-08-18 23:43:42.25189+09
491	2	send	to=01012345678 job=421	\N	2026-08-18 23:43:42.347229+09
492	2	send	to=01012345678 job=422	\N	2026-08-19 00:08:59.918726+09
493	2	send	to=01012345678 job=423	\N	2026-08-19 00:21:03.755337+09
494	2	send	to=01012345678 job=424	\N	2026-08-19 00:37:37.558564+09
495	2	send	to=01012345678 job=425	\N	2026-08-19 00:43:21.336795+09
496	2	send	to=05041638984 job=426	\N	2026-08-19 00:50:36.937257+09
497	2	send	to=05041638984 job=427	\N	2026-08-19 00:55:21.552505+09
498	2	send	to=01012345678 job=428	\N	2026-08-19 01:06:21.759905+09
499	2	login	success	192.168.219.141	2026-08-19 23:57:19.964261+09
500	2	login	success	192.168.219.141	2026-08-20 07:26:18.287968+09
501	2	login	success	192.168.219.141	2026-08-30 20:41:24.438252+09
502	2	login	success	127.0.0.1	2026-08-31 01:38:42.35483+09
503	2	send	to=1002 job=429	\N	2026-08-31 01:38:43.454922+09
504	2	login	success	192.168.219.141	2026-08-31 01:40:44.280225+09
505	2	login	success	192.168.219.141	2026-08-31 01:47:16.424464+09
506	2	login	success	127.0.0.1	2026-08-31 01:49:45.109051+09
507	2	send	to=1002 job=430	\N	2026-08-31 01:49:45.565197+09
508	2	login	success	192.168.219.141	2026-08-31 01:50:53.810975+09
509	2	login	success	127.0.0.1	2026-08-31 01:52:02.625995+09
510	2	login	success	127.0.0.1	2026-08-31 02:14:37.153822+09
511	2	login	success	127.0.0.1	2026-08-31 02:17:57.351375+09
512	2	login	success	127.0.0.1	2026-08-31 02:54:58.25594+09
513	2	login	success	127.0.0.1	2026-08-31 02:54:58.430829+09
514	2	login_fail	bad password	127.0.0.1	2026-08-31 02:56:16.387682+09
515	2	login	success	127.0.0.1	2026-08-31 02:56:21.938779+09
516	2	login	success	127.0.0.1	2026-08-31 02:56:22.117841+09
517	2	login	success	127.0.0.1	2026-08-31 02:57:59.99749+09
518	2	login	success	127.0.0.1	2026-08-31 02:58:40.658587+09
519	2	login	success	127.0.0.1	2026-08-31 02:59:49.799472+09
520	2	send	to=1002 job=431	\N	2026-08-31 02:59:50.41378+09
521	2	send	to=1002 job=432	\N	2026-08-31 02:59:50.9217+09
522	2	send	to=1002 job=433	\N	2026-08-31 02:59:51.406394+09
523	2	login	success	127.0.0.1	2026-08-31 03:03:55.3115+09
524	2	send	to=1002 job=434	\N	2026-08-31 03:03:55.792283+09
525	2	send	to=1002 job=435	\N	2026-08-31 03:03:56.260863+09
526	2	send	to=1002 job=436	\N	2026-08-31 03:03:56.741689+09
527	2	send	to=1002 job=437	\N	2026-08-31 03:03:57.215165+09
528	2	send	to=1002 job=438	\N	2026-08-31 03:03:57.774634+09
529	2	send	to=1002 job=439	\N	2026-08-31 03:03:58.318591+09
530	2	send	to=1002 job=440	\N	2026-08-31 03:03:58.868135+09
531	2	send	to=1002 job=441	\N	2026-08-31 03:03:59.398997+09
532	2	send	to=1002 job=442	\N	2026-08-31 03:03:59.976528+09
533	2	send	to=1002 job=443	\N	2026-08-31 03:04:00.498388+09
534	2	login	success	192.168.219.141	2026-08-31 17:39:22.975614+09
535	2	login	success	192.168.219.141	2026-08-31 17:45:45.722199+09
536	2	cancel	job=443	\N	2026-08-31 17:46:14.713056+09
537	2	login	success	127.0.0.1	2026-08-31 18:09:29.606789+09
538	2	login	success	127.0.0.1	2026-08-31 18:09:36.198174+09
539	2	login	success	127.0.0.1	2026-08-31 18:13:36.067542+09
540	2	bulk_delete	1건 삭제, 2건 건너뜀	\N	2026-08-31 18:13:36.081489+09
541	2	login	success	192.168.219.141	2026-08-31 18:13:43.857993+09
542	2	login	success	192.168.219.141	2026-08-31 18:20:02.332122+09
543	2	bulk_delete	30건 삭제, 70건 건너뜀	\N	2026-08-31 18:20:54.680083+09
544	2	bulk_delete	70건 삭제, 30건 건너뜀 (force)	\N	2026-08-31 18:20:59.290965+09
545	2	login	success	127.0.0.1	2026-08-31 18:21:39.427198+09
546	2	bulk_delete	0건 삭제, 3건 건너뜀	\N	2026-08-31 18:21:39.437495+09
547	2	login	success	127.0.0.1	2026-08-31 18:25:06.146798+09
548	2	bulk_delete	3건 삭제, 0건 건너뜀 (force)	\N	2026-08-31 18:25:06.158599+09
549	2	login	success	192.168.219.141	2026-08-31 18:25:38.193952+09
550	2	bulk_delete	60건 삭제, 40건 건너뜀	\N	2026-08-31 18:32:03.241762+09
551	2	bulk_delete	40건 삭제, 60건 건너뜀 (force)	\N	2026-08-31 18:32:05.296276+09
552	2	bulk_delete	6건 삭제, 94건 건너뜀	\N	2026-08-31 18:32:34.695651+09
553	2	bulk_delete	94건 삭제, 6건 건너뜀 (force)	\N	2026-08-31 18:32:36.208893+09
554	2	login	success	127.0.0.1	2026-08-31 18:36:17.596219+09
555	2	bulk_delete	3건 삭제, 0건 건너뜀 (force)	\N	2026-08-31 18:36:17.607418+09
556	2	bulk_delete	3건 삭제, 0건 건너뜀 (force)	\N	2026-08-31 18:36:17.617404+09
557	2	bulk_delete	3건 삭제, 0건 건너뜀 (force)	\N	2026-08-31 18:36:17.62795+09
558	2	login	success	192.168.219.141	2026-08-31 18:42:32.861391+09
559	2	login	success	192.168.219.141	2026-08-31 18:50:47.580104+09
560	2	bulk_delete	0건 삭제, 100건 건너뜀	\N	2026-08-31 18:55:52.805223+09
561	2	bulk_delete	100건 삭제, 0건 건너뜀 (force)	\N	2026-08-31 18:55:55.065193+09
562	2	bulk_delete	0건 삭제, 8건 건너뜀	\N	2026-08-31 18:57:50.442391+09
563	2	bulk_delete	8건 삭제, 0건 건너뜀 (force)	\N	2026-08-31 18:57:56.052732+09
564	2	login	success	192.168.219.141	2026-08-31 19:09:04.537059+09
565	2	login	success	192.168.219.141	2026-08-31 19:37:30.626269+09
598	2	login	success	192.168.219.141	2026-09-01 04:19:19.783251+09
599	2	login	success	127.0.0.1	2026-09-01 04:22:31.797256+09
600	2	send	to=1002 job=444	\N	2026-09-01 04:22:32.891414+09
601	2	send	to=1002 job=445	\N	2026-09-01 04:22:33.666402+09
602	2	send	to=1002 job=446	\N	2026-09-01 04:22:34.439825+09
603	2	send	to=1002 job=447	\N	2026-09-01 04:22:35.210084+09
604	2	send	to=1002 job=448	\N	2026-09-01 04:22:35.971402+09
605	2	send	to=1002 job=449	\N	2026-09-01 04:22:36.740132+09
606	2	send	to=1002 job=450	\N	2026-09-01 04:22:37.500136+09
607	2	send	to=1002 job=451	\N	2026-09-01 04:22:38.270037+09
608	2	send	to=1002 job=452	\N	2026-09-01 04:22:39.036679+09
609	2	send	to=1002 job=453	\N	2026-09-01 04:22:39.789064+09
610	2	login	success	127.0.0.1	2026-09-01 11:57:06.04773+09
611	2	send	to=1002 job=454	\N	2026-09-01 11:57:08.37929+09
612	2	send	to=1002 job=455	\N	2026-09-01 11:57:09.560816+09
613	2	send	to=1002 job=456	\N	2026-09-01 11:57:10.576884+09
614	2	send	to=1002 job=457	\N	2026-09-01 11:57:11.380143+09
615	2	send	to=1002 job=458	\N	2026-09-01 11:57:12.276699+09
616	2	send	to=1002 job=459	\N	2026-09-01 11:57:13.122583+09
617	2	send	to=1002 job=460	\N	2026-09-01 11:57:13.918496+09
618	2	send	to=1002 job=461	\N	2026-09-01 11:57:14.722028+09
619	2	send	to=1002 job=462	\N	2026-09-01 11:57:15.689287+09
620	2	send	to=1002 job=463	\N	2026-09-01 11:57:16.487715+09
621	2	login	success	192.168.219.141	2026-09-01 11:57:31.941775+09
622	2	bulk_delete	20건 삭제, 0건 건너뜀 (force)	\N	2026-09-01 12:14:58.403289+09
623	2	send	to=1002 job=464	\N	2026-09-01 12:31:02.394606+09
624	2	send	to=1002 job=465	\N	2026-09-01 12:54:16.988019+09
625	2	login	success	127.0.0.1	2026-09-01 12:57:30.305454+09
626	2	send	to=1002 job=466	\N	2026-09-01 12:57:30.89041+09
627	2	login	success	127.0.0.1	2026-09-01 13:01:28.2014+09
628	2	send	to=1002 job=467	\N	2026-09-01 13:01:28.697454+09
629	2	bulk_delete	4건 삭제, 0건 건너뜀 (force)	\N	2026-09-01 13:11:03.746297+09
630	2	login	success	192.168.219.141	2026-09-01 13:14:20.361713+09
631	2	send	to=1002 job=468	\N	2026-09-01 13:17:03.627739+09
632	2	send	to=1234 job=469	\N	2026-09-01 13:21:18.861773+09
633	2	login	success	192.168.219.141	2026-09-01 13:23:06.735207+09
634	2	bulk_delete	2건 삭제, 0건 건너뜀	\N	2026-09-01 13:24:08.79734+09
635	2	login	success	127.0.0.1	2026-09-01 13:26:27.805964+09
640	2	send	to=1002 job=474	\N	2026-09-01 13:26:32.052094+09
636	2	send	to=1002 job=470	\N	2026-09-01 13:26:28.47083+09
637	2	send	to=1002 job=471	\N	2026-09-01 13:26:29.462751+09
638	2	send	to=1002 job=472	\N	2026-09-01 13:26:30.385792+09
641	2	send	to=1002 job=475	\N	2026-09-01 13:26:32.861201+09
642	2	send	to=1002 job=476	\N	2026-09-01 13:26:33.693934+09
643	2	send	to=1002 job=477	\N	2026-09-01 13:26:34.59126+09
644	2	send	to=1002 job=478	\N	2026-09-01 13:26:35.440218+09
645	2	send	to=1002 job=479	\N	2026-09-01 13:26:36.273043+09
646	2	login	success	127.0.0.1	2026-09-01 13:45:31.541+09
648	2	send	to=1002 job=481	\N	2026-09-01 13:45:32.843389+09
650	2	send	to=1002 job=483	\N	2026-09-01 13:45:34.456488+09
652	2	send	to=1002 job=485	\N	2026-09-01 13:45:36.095162+09
654	2	send	to=1002 job=487	\N	2026-09-01 13:45:37.708645+09
656	2	send	to=1002 job=489	\N	2026-09-01 13:45:39.361474+09
639	2	send	to=1002 job=473	\N	2026-09-01 13:26:31.24499+09
647	2	send	to=1002 job=480	\N	2026-09-01 13:45:32.033878+09
649	2	send	to=1002 job=482	\N	2026-09-01 13:45:33.638121+09
651	2	send	to=1002 job=484	\N	2026-09-01 13:45:35.282228+09
653	2	send	to=1002 job=486	\N	2026-09-01 13:45:36.900822+09
655	2	send	to=1002 job=488	\N	2026-09-01 13:45:38.539469+09
657	2	send	to=1002 job=490	\N	2026-09-01 15:17:25.27427+09
658	2	bulk_delete	20건 삭제, 0건 건너뜀 (force)	\N	2026-09-01 15:18:59.10597+09
659	2	login	success	127.0.0.1	2026-09-01 15:20:24.550741+09
660	2	send	to=1002 job=491	\N	2026-09-01 15:20:25.086423+09
661	2	login	success	192.168.219.141	2026-09-02 11:56:11.885369+09
662	2	bulk_delete	2건 삭제, 0건 건너뜀 (force)	\N	2026-09-02 11:56:46.890718+09
663	2	login	success	192.168.219.141	2026-09-03 04:33:34.153447+09
664	2	login	success	192.168.219.141	2026-09-03 05:15:11.496088+09
665	2	login	success	192.168.219.141	2026-09-04 04:32:18.645528+09
666	2	login	success	192.168.219.141	2026-09-04 04:34:30.53828+09
667	2	login	success	192.168.219.141	2026-09-04 04:43:50.540581+09
668	2	login	success	192.168.219.118	2026-09-04 04:44:16.982747+09
669	2	login	success	192.168.219.141	2026-09-04 04:50:07.725982+09
670	2	login	success	192.168.219.141	2026-09-10 02:10:02.443355+09
671	2	login	success	192.168.219.141	2026-09-11 01:56:04.582644+09
\.


--
-- Data for Name: contact_group_members; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.contact_group_members (group_id, contact_id) FROM stdin;
\.


--
-- Data for Name: contact_groups; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.contact_groups (id, owner_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.contacts (id, owner_id, name, fax_number, company, memo, is_shared, created_at) FROM stdin;
\.


--
-- Data for Name: cover_templates; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.cover_templates (id, owner_id, name, content, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.departments (id, name, parent_id, fax_number, created_at) FROM stdin;
\.


--
-- Data for Name: error_log; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.error_log (id, code, category, detail, context, path, user_id, job_id, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: fax_jobs; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.fax_jobs (id, user_id, dept_id, to_number, to_name, file_name, file_path, pages, cover_used, status, server_job_id, retry_count, result_text, batch_id, created_at, sent_at, max_retries, next_retry_at, last_error_code, scheduled_at, pages_sent, diag_category, t38_used, transfer_rate, hangup_cause, api_key_id, ecm_used, bad_rows) FROM stdin;
\.


--
-- Data for Name: fax_received; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.fax_received (id, from_number, to_number, dept_id, user_id, file_path, pages, rate, is_read, memo, received_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, level, title, body, category, ref_type, ref_id, is_read, created_at) FROM stdin;
35	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	278	t	2026-08-18 19:17:38.13182+09
40	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	280	t	2026-08-18 19:17:54.909669+09
45	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	286	t	2026-08-18 19:18:13.930154+09
48	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	289	t	2026-08-18 19:18:28.709714+09
50	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	291	t	2026-08-18 19:18:30.65265+09
36	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	276	t	2026-08-18 19:17:39.308774+09
46	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	287	t	2026-08-18 19:18:14.102965+09
51	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	292	t	2026-08-18 19:18:44.4048+09
37	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	277	t	2026-08-18 19:17:39.43859+09
52	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	293	t	2026-08-18 19:18:44.89299+09
38	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	279	t	2026-08-18 19:17:40.517626+09
41	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	281	t	2026-08-18 19:17:56.319347+09
43	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	284	t	2026-08-18 19:18:11.308632+09
47	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	288	t	2026-08-18 19:18:27.184783+09
49	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	290	t	2026-08-18 19:18:29.931203+09
54	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	295	t	2026-08-18 19:18:46.31662+09
85	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	416	t	2026-08-18 23:45:30.716493+09
88	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	419	t	2026-08-18 23:45:35.861327+09
86	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	417	t	2026-08-18 23:45:33.803002+09
89	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	420	t	2026-08-18 23:45:48.492535+09
1	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	242	t	2026-08-18 19:12:35.104852+09
2	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	243	t	2026-08-18 19:12:35.64983+09
3	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	244	t	2026-08-18 19:12:35.883697+09
4	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	245	t	2026-08-18 19:12:35.9723+09
5	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	247	t	2026-08-18 19:12:51.349189+09
6	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	246	t	2026-08-18 19:12:52.116313+09
7	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	249	t	2026-08-18 19:12:52.488761+09
8	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	248	t	2026-08-18 19:12:52.903001+09
9	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	250	t	2026-08-18 19:13:07.206008+09
10	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	251	t	2026-08-18 19:13:07.684143+09
11	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	252	t	2026-08-18 19:13:08.27017+09
12	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	253	t	2026-08-18 19:13:11.085859+09
13	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	254	t	2026-08-18 19:13:23.860979+09
14	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	256	t	2026-08-18 19:13:24.301613+09
15	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	255	t	2026-08-18 19:13:24.95529+09
16	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	257	t	2026-08-18 19:13:28.253055+09
17	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	258	t	2026-08-18 19:13:39.891592+09
18	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	260	t	2026-08-18 19:13:40.449264+09
19	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	259	t	2026-08-18 19:13:40.663564+09
20	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	261	t	2026-08-18 19:13:45.289657+09
21	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	262	t	2026-08-18 19:13:55.338867+09
22	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	263	t	2026-08-18 19:13:56.006383+09
23	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	264	t	2026-08-18 19:13:56.487048+09
24	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	265	t	2026-08-18 19:14:00.431604+09
25	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	266	t	2026-08-18 19:14:11.147779+09
26	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	267	t	2026-08-18 19:14:12.741904+09
27	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	268	t	2026-08-18 19:14:12.888791+09
28	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	269	t	2026-08-18 19:14:16.056136+09
29	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	270	t	2026-08-18 19:14:25.631124+09
30	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	271	t	2026-08-18 19:14:28.060882+09
31	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	273	t	2026-08-18 19:17:21.713371+09
32	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	274	t	2026-08-18 19:17:22.00064+09
33	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	275	t	2026-08-18 19:17:22.648721+09
34	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	272	t	2026-08-18 19:17:23.986612+09
39	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	282	t	2026-08-18 19:17:54.494801+09
42	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	283	t	2026-08-18 19:17:58.177641+09
44	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	285	t	2026-08-18 19:18:12.437098+09
53	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	294	t	2026-08-18 19:18:45.595182+09
55	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	296	t	2026-08-18 19:19:00.883946+09
56	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	297	t	2026-08-18 19:19:01.290847+09
57	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	298	t	2026-08-18 19:19:01.627995+09
58	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	299	t	2026-08-18 19:19:02.20853+09
59	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	300	t	2026-08-18 19:19:16.370745+09
60	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	301	t	2026-08-18 19:19:17.200545+09
61	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	392	t	2026-08-18 23:43:55.55263+09
62	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	395	t	2026-08-18 23:43:56.356111+09
63	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	394	t	2026-08-18 23:43:56.643984+09
64	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	393	t	2026-08-18 23:43:57.132473+09
65	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	396	t	2026-08-18 23:44:11.292028+09
66	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	397	t	2026-08-18 23:44:11.71033+09
67	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	399	t	2026-08-18 23:44:13.246956+09
68	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	398	t	2026-08-18 23:44:13.601607+09
69	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	401	t	2026-08-18 23:44:26.821195+09
70	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	400	t	2026-08-18 23:44:28.596293+09
71	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	402	t	2026-08-18 23:44:29.639912+09
72	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	403	t	2026-08-18 23:44:30.789687+09
73	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	404	t	2026-08-18 23:44:42.449661+09
74	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	405	t	2026-08-18 23:44:45.261989+09
75	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	406	t	2026-08-18 23:44:46.276268+09
76	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	407	t	2026-08-18 23:44:47.655626+09
77	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	408	t	2026-08-18 23:44:58.69367+09
78	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	409	t	2026-08-18 23:45:01.746321+09
79	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	411	t	2026-08-18 23:45:03.020069+09
80	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	410	t	2026-08-18 23:45:03.177802+09
81	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	412	t	2026-08-18 23:45:14.64402+09
82	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	413	t	2026-08-18 23:45:16.994089+09
83	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	414	t	2026-08-18 23:45:18.115906+09
84	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	415	t	2026-08-18 23:45:20.118424+09
87	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	418	t	2026-08-18 23:45:34.363802+09
90	2	warn	팩스 발송 실패 · ?	원인: 상대 팩스기와 호환되지 않거나 수신할 수 없습니다.\n책임 소재: 미상 쪽\n코드: REMOTE_INCOMPATIBLE	send_fail	job	421	t	2026-08-18 23:45:50.9833+09
\.


--
-- Data for Name: notify_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notify_config (id, webhook_url, notify_on_fail, notify_on_recv, fault_filter) FROM stdin;
1	\N	t	f	local
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: faxapp
--

COPY public.users (id, username, password_hash, display_name, email, dept_id, fax_number, role, is_active, created_at, last_login) FROM stdin;
2	admin	$2b$12$/gbjxLk9EHCTiSqrODK5UO2IUPxy0.vU9lR1p.kCKUhBg.9nHML0m	관리자	\N	\N	\N	admin	t	2026-08-08 19:47:54.386456+09	2026-09-11 01:56:04.577292+09
3	jhchang	$2b$12$EFknR0.ZdtaQVwFo.tjoXeSd2uZQ2bS2EtX2AruO5wU6afoVhu3Ly	junho	\N	\N		admin	t	2026-08-09 05:11:31.035114+09	\N
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 34, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 671, true);


--
-- Name: contact_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.contact_groups_id_seq', 1, false);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.contacts_id_seq', 2, true);


--
-- Name: cover_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.cover_templates_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: error_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.error_log_id_seq', 1763, true);


--
-- Name: fax_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.fax_jobs_id_seq', 491, true);


--
-- Name: fax_received_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.fax_received_id_seq', 122, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 90, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: faxapp
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: contact_group_members contact_group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contact_group_members
    ADD CONSTRAINT contact_group_members_pkey PRIMARY KEY (group_id, contact_id);


--
-- Name: contact_groups contact_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contact_groups
    ADD CONSTRAINT contact_groups_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: cover_templates cover_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.cover_templates
    ADD CONSTRAINT cover_templates_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: error_log error_log_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.error_log
    ADD CONSTRAINT error_log_pkey PRIMARY KEY (id);


--
-- Name: fax_jobs fax_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_jobs
    ADD CONSTRAINT fax_jobs_pkey PRIMARY KEY (id);


--
-- Name: fax_received fax_received_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_received
    ADD CONSTRAINT fax_received_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: notify_config notify_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notify_config
    ADD CONSTRAINT notify_config_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_apikey_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_apikey_hash ON public.api_keys USING btree (key_hash) WHERE is_active;


--
-- Name: idx_audit_time; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_audit_time ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_contacts_owner; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_contacts_owner ON public.contacts USING btree (owner_id);


--
-- Name: idx_error_category; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_error_category ON public.error_log USING btree (category);


--
-- Name: idx_error_code; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_error_code ON public.error_log USING btree (code);


--
-- Name: idx_error_job; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_error_job ON public.error_log USING btree (job_id);


--
-- Name: idx_error_time; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_error_time ON public.error_log USING btree (created_at);


--
-- Name: idx_jobs_batch; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_jobs_batch ON public.fax_jobs USING btree (batch_id);


--
-- Name: idx_jobs_created; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_jobs_created ON public.fax_jobs USING btree (created_at);


--
-- Name: idx_jobs_retry; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_jobs_retry ON public.fax_jobs USING btree (next_retry_at) WHERE ((status)::text = 'retry_wait'::text);


--
-- Name: idx_jobs_scheduled; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_jobs_scheduled ON public.fax_jobs USING btree (scheduled_at) WHERE ((status)::text = 'scheduled'::text);


--
-- Name: idx_jobs_status; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_jobs_status ON public.fax_jobs USING btree (status);


--
-- Name: idx_jobs_user; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_jobs_user ON public.fax_jobs USING btree (user_id);


--
-- Name: idx_notif_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notif_user ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_recv_dept; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_recv_dept ON public.fax_received USING btree (dept_id);


--
-- Name: idx_recv_read; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_recv_read ON public.fax_received USING btree (is_read);


--
-- Name: idx_recv_to; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_recv_to ON public.fax_received USING btree (to_number);


--
-- Name: idx_users_dept; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_users_dept ON public.users USING btree (dept_id);


--
-- Name: idx_users_fax; Type: INDEX; Schema: public; Owner: faxapp
--

CREATE INDEX idx_users_fax ON public.users USING btree (fax_number);


--
-- Name: api_keys api_keys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: contact_group_members contact_group_members_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contact_group_members
    ADD CONSTRAINT contact_group_members_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: contact_group_members contact_group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contact_group_members
    ADD CONSTRAINT contact_group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.contact_groups(id) ON DELETE CASCADE;


--
-- Name: contact_groups contact_groups_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contact_groups
    ADD CONSTRAINT contact_groups_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cover_templates cover_templates_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.cover_templates
    ADD CONSTRAINT cover_templates_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: fax_jobs fax_jobs_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_jobs
    ADD CONSTRAINT fax_jobs_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id) ON DELETE SET NULL;


--
-- Name: fax_jobs fax_jobs_dept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_jobs
    ADD CONSTRAINT fax_jobs_dept_id_fkey FOREIGN KEY (dept_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: fax_jobs fax_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_jobs
    ADD CONSTRAINT fax_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fax_received fax_received_dept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_received
    ADD CONSTRAINT fax_received_dept_id_fkey FOREIGN KEY (dept_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: fax_received fax_received_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.fax_received
    ADD CONSTRAINT fax_received_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_dept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: faxapp
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_dept_id_fkey FOREIGN KEY (dept_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: TABLE api_keys; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.api_keys TO faxapp;


--
-- Name: SEQUENCE api_keys_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.api_keys_id_seq TO faxapp;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notifications TO faxapp;


--
-- Name: SEQUENCE notifications_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notifications_id_seq TO faxapp;


--
-- Name: TABLE notify_config; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notify_config TO faxapp;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO faxapp;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO faxapp;


--
-- PostgreSQL database dump complete
--

\unrestrict HTzPxOrgnB9zf9SAQP9A9ecThHW4hRdsAVM6BgVemzvctjmzCxMxTFvV5IRcOQH

